from rich.console import Console
from rich.layout import Layout
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from datetime import datetime
import sys
import os

# Adiciona o diretório system ao path
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'system'))
from memory import MemoryGraph
from companion import Companion

class EZOS_TUI:
    def __init__(self):
        self.console = Console()
        self.memory = MemoryGraph()
        self.companion = Companion(seed="user-123") # Mock seed
        self.companion.update_state(self.memory)

    def make_layout(self) -> Layout:
        layout = Layout()
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="main", ratio=1),
            Layout(name="footer", size=3)
        )
        layout["main"].split_row(
            Layout(name="side", size=30),
            Layout(name="body", ratio=1)
        )
        return layout

    def get_header(self):
        return Panel(
            Text("EZ-OS | Sistema Operacional de Memória Lúdica", justify="center", style="bold cyan"),
            style="white"
        )

    def get_sidebar(self):
        stats = self.companion.state
        content = f"[bold cyan]Mascote:[/bold cyan] {self.companion.name}\n"
        content += f"[bold cyan]Fase:[/bold cyan] {stats['phase']}\n"
        content += f"[bold cyan]Energia:[/bold cyan] [green]{stats['energy']}%[/green]\n"
        content += f"[bold cyan]Foco:[/bold cyan] {stats['focus']}\n\n"
        content += "[dim]────────────────────[/dim]\n\n"
        content += "[bold yellow]MENU[/bold yellow]\n"
        content += "• [white]Jogar[/white]\n"
        content += "• [white]Memórias[/white]\n"
        content += "• [white]Config[/white]\n"
        content += "• [white]Sair[/white]"
        
        return Panel(content, title="[bold blue]Status[/bold blue]", border_style="blue")

    def get_body(self):
        ascii_art = self.companion.get_ascii_art()
        events = self.memory.get_latest_events(5)
        
        table = Table(expand=True, border_style="dim")
        table.add_column("Data", style="dim", width=20)
        table.add_column("Evento", style="white")
        
        for e in events:
            table.add_row(e["timestamp"][:16], e["properties"].get("description", "Evento desconhecido"))

        # Combine ASCII and Table
        body_content = Layout()
        body_content.split_column(
            Layout(Panel(Text(ascii_art, justify="center", style="bold yellow"), title="[bold green]Companion[/bold green]", border_style="green"), ratio=2),
            Layout(Panel(table, title="[bold magenta]Log de Memória[/bold magenta]", border_style="magenta"), ratio=1)
        )
        
        return body_content

    def run(self):
        layout = self.make_layout()
        layout["header"].update(self.get_header())
        layout["side"].update(self.get_sidebar())
        layout["body"].update(self.get_body())
        layout["footer"].update(Panel(Text("O EZ-OS não tenta prender o jogador. Ele apenas lembra quando ele volta.", justify="center", style="italic dim")))
        
        self.console.print(layout)

if __name__ == "__main__":
    tui = EZOS_TUI()
    tui.run()
