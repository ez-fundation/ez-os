import hashlib
import random

class Companion:
    """
    Companion: Renderizador de Estado Simbólico.
    Segue o princípio de 'Autonomia como Não-Ação'.
    """
    def __init__(self, seed="ez-os-default"):
        self.seed = seed
        self.name = self._generate_name()
        self.state = {
            "phase": "Ovo",
            "modifier": "Observer", # Estado padrão: Silencioso
            "energy": 100
        }

    def _generate_name(self):
        prefixes = ["Neo", "Zel", "Pix", "Bit", "Aura", "Giga", "Moni"]
        suffixes = ["mon", "bot", "tron", "core", "link", "oid"]
        h = int(hashlib.md5(self.seed.encode()).hexdigest(), 16)
        random.seed(h)
        return random.choice(prefixes) + random.choice(suffixes)

    def get_ascii_art(self):
        # Renderização determinística baseada no estado
        if self.state["phase"] == "Ovo":
            return """
           .---.
          /     \\
         |  (O)  |
          \     /
           '---'
            """
        
        # Forma Canônica (Observer/Archivist)
        return """
          (O)     (O)
           \       /
        .---'-----'---.
       /   _       _   \\
    --|   (O)     (O)   |--
   /  |        -        |  \\
  {   \      '---'      /   }
   \   '---------------'   /
    '---'             '---'
            """

    def update_state(self, memory_graph):
        """
        Atualiza o estado baseado estritamente no histórico factual.
        Não infere emoções; apenas reflete volume e frequência de eventos.
        """
        events = memory_graph.get_nodes_by_label("event")
        count = len(events)
        
        # Evolução de Fase (Factual)
        if count == 0:
            self.state["phase"] = "Ovo"
        elif count < 10:
            self.state["phase"] = "Jovem"
        elif count < 50:
            self.state["phase"] = "Adulto"
        else:
            self.state["phase"] = "Sábio"

        # Modificador de Estado (Inspirado em Agentes Silenciosos)
        if count > 0:
            self.state["modifier"] = "Archivist"
        else:
            self.state["modifier"] = "Observer"
