# 🧠 EZ-OS v1.0-LAYER

> **Memory Layer for Retro Systems**
>
> Esta versão roda sobre o ArkOS/Linux base, validando o conceito do EZ-OS em hardware real (R35S) sem risco técnico ou necessidade de port complexo.

## 🎯 Propósito
- Validar o EZ-OS em hardware real.
- Demonstrar valor através do registro factual de memórias.
- Servir como base de licenciamento.

## 📦 Estrutura
- `core/`: O núcleo congelado (v1.0-FINAL).
- `integration/`: Scripts de hook para ArkOS/RetroArch.
- `data/`: Grafo de memória e configurações locais.

## ⏱️ Experiência de Uso
1. O console inicia no ArkOS.
2. O EZ-OS é aberto como shell primário.
3. O usuário seleciona e joga.
4. O EZ-OS registra o evento e retorna silenciosamente após a sessão.

---
*Esta versão prova o conceito sem se comprometer com o futuro.*
